Studenten: Faris van Hien (5937949), Jeroen Maassen(5963761)
Wij hebben ��n extra opdract ge�mplementeerd:
- Functionaliteit waarmee het speelveld in- en uitgezoomd kan worden.
Je kunt met de 'Z' en 'X' toetsen in- en uitzoomen.